portify
=======

Transfers your Spotify playlists to Google Music: All Access

By using Portify you may violate both Spotify's and Google's Terms of Service. You agree that
you are using Portify on your own risk. The author does not accept liability (as far as permitted by law) for any loss arising from any use of this tool.
If you choose not to agree to these terms, then you may not use this tool.

License
-------

Licensed under the terms of the Apache 2.0 License